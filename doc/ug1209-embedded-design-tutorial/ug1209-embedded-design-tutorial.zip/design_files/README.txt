*************************************************************************
   ____  ____ 
  /   /\/   / 
 /___/  \  /   
 \   \   \/    � Copyright 2017 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary 
  /   /        information of Xilinx, Inc. and is protected under U.S. 
 /___/   /\    and international copyright and other intellectual 
 \   \  /  \   property laws. 
  \___\/\___\ 
 
*************************************************************************

Vendor: Xilinx 
Current readme.txt Version: 4.0
Date Last Modified:  30Oct2017
Date Created: 23MAY2016

Associated Filename: ug1209-embedded-design-tutorial.zip
Associated Document: UG1209, Zynq UltraScale+ MPSoC: Embedded Design Tutorial

Supported Device(s): Zynq UltraScale+ MPSoC
   
*************************************************************************

Disclaimer: 

      This disclaimer is not a license and does not grant any rights to 
      the materials distributed herewith. Except as otherwise provided in 
      a valid license issued to you by Xilinx, and to the maximum extent 
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE 
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL 
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, 
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and 
      (2) Xilinx shall not be liable (whether in contract or tort, 
      including negligence, or under any other theory of liability) for 
      any loss or damage of any kind or nature related to, arising under 
      or in connection with these materials, including for any direct, or 
      any indirect, special, incidental, or consequential loss or damage 
      (including loss of data, profits, goodwill, or any type of loss or 
      damage suffered as a result of any action brought by a third party) 
      even if such damage or loss was reasonably foreseeable or Xilinx 
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or 
      for use in any application requiring fail-safe performance, such as 
      life-support or safety devices or systems, Class III medical 
      devices, nuclear facilities, applications related to the deployment 
      of airbags, or any other applications that could lead to death, 
      personal injury, or severe property or environmental damage 
      (individually and collectively, "Critical Applications"). Customer 
      assumes the sole risk and liability of any use of Xilinx products 
      in Critical Applications, subject only to applicable laws and 
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS 
FILE AT ALL TIMES.

*************************************************************************

REVISION HISTORY 


            Readme  
Date        Version      Revision Description
=========================================================================
23MAY2016   1.0          Initial Xilinx release.
23AUG2016   1.1		 Updated for Vivado/SDK 2016.2 release.
18Nov2016   2.1		 Update with Vivado/SDK 2016.3 release and
			 added a Graphics application to run on DP
14Jul2017   3.0		 -USB Boot added to Boot and Configuration in Chapter 5.
			 -Secure Boot Sequence in Chapter 5 revised with more
			  details and steps.
			 -Validated with Vivado� Design Suite 2017.1.
			 -Tested steps and design-files on ZCU102 Rev1 Board
			  with Production Silicon.		
22Aug2017  3.1		 Updated the tutorial for 2017.2 Tools updates
31Oct2017  4.0		 Added Isolation and FSBL Debug
					 Added U-boot Settings in PetaLinux 2017.3 for USB boot	
					 Updated the tutorial for 2017.3 Tools updates
=========================================================================

DESIGN FILE HIERARCHY

The directory structure underneath this top-level folder is described 
below:

\Design_Files
|
|-- Linux Image amd RPU Application source which is applicable
|	to most of the sections except Design1 and Design2.
|
|-- \sd_boot
|
|	Contains paritions used in SD Boot section, The BIF File
|	and prebuilt image, Boot.bin
|
|-- \qspi_boot
|
|	Contains paritions used in QSPI Boot section, The BIF File
|	and prebuilt image, qspi_boot.bin
|
|
|-- \usb-boot
|	Contains paritions used in USB Boot section, The BIF Files
|	and prebuilt images
|
|
|-- \secureboot_sd
|
|	Contains individual project for key generataion and
|	different Secure Boot scenarios. Each folder contains related
|	BIF file, referenced secure Keys, and generated Image.
|	The Executable partititions for this section can be used
|	from Sd_boot folder
|
|-- \design1
|	Contains the Hardware Definition File for this Design example 1,
|	Application source codes used for design1, BIF File
|	and prebuilt images for Design 1 section of EDT
|
|-- \design2
	Contains the Hardware Definition File for Design example 2,
	Tricube Graphics Application source code (based on X window),
	device tree file for Display Port Dual lane configuration,
	runtricube.sh shell script, and prebuilt images,
	eglfbdev graphics application based on fbdev.

SUPPORT

To obtain technical support for this reference design, go to 
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database or to create a WebCase.  